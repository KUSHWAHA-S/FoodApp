import React from 'react'
import './Style.css';


function Loader() {
    console.log("helo");
  return (
    <div style={{}}>
    <span className="loader"></span>
    </div>
  )
}

export default Loader