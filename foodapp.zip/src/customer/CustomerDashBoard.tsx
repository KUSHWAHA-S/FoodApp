import React , {useState} from 'react';
// import {Routes, Route} from 'react-router-dom';
import {BrowserRouter,Route} from 'react-router-dom';
import logo from './logo.svg';
// import POP from './POP';
import './App.css';


function CustomerDashBoard() {

 
  return (
    <div>hello</div>
  );
}

export default CustomerDashBoard;