import React from 'react'
import './Style.css';


function Loader() {
    console.log("helLo");
  return (
    <div style={{}}>
    <span className="loader"></span>
    </div>
  )
}

export default Loader